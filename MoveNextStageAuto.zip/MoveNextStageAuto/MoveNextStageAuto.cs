﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using System.Text;

namespace MoveNextStageAuto
{
    public class MoveNextStageAuto : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            //IOrganizationService crmService = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService crmService = serviceFactory.CreateOrganizationService(null);
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                StringBuilder strBuilder = new StringBuilder();
                string logicalNameOfBPF = "new_testbpf";
                if (context.MessageName.ToLower().Equals("update") && context.PrimaryEntityName.ToLower().Equals("new_testentity"))
                {
                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                    {
                        Entity entity = (Entity)context.InputParameters["Target"];
                        if (entity.Contains("new_name") && entity["new_name"] != null)
                        {
                            Entity activeProcessInstance = GetActiveBPF( entity, crmService);

                            if(activeProcessInstance != null)
                            {
                                Guid activeBPFId = activeProcessInstance.Id; // Id of the active process instance, which will be used

                                // Retrieve the active stage ID of in the active process instance
                                Guid activeStageId = new Guid(activeProcessInstance.Attributes["processstageid"].ToString());

                                int activeStagePosition = -1;
                                RetrieveActivePathResponse pathResp = GetAllStagesOfBPF(activeBPFId, activeStageId, ref activeStagePosition, crmService);

                                if(activeStagePosition > -1 && pathResp.ProcessStages != null && pathResp.ProcessStages.Entities != null)
                                {
                                    if (activeStagePosition + 1 < pathResp.ProcessStages.Entities.Count)
                                    {
                                        // Retrieve the stage ID of the next stage that you want to set as active
                                        Guid nextStageId = (Guid)pathResp.ProcessStages.Entities[activeStagePosition + 1].Attributes["processstageid"];

                                        // Set the next stage as the active stage
                                        Entity entBPF = new Entity(logicalNameOfBPF);
                                        entBPF.Id = activeBPFId;
                                        entBPF["activestageid"] = new EntityReference("processstage", nextStageId);
                                        crmService.Update(entBPF);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw ex;
            }
        }

        public Entity GetActiveBPF(Entity entity, IOrganizationService crmService)
        {
            Entity activeProcessInstance = null;
            RetrieveProcessInstancesRequest entityBPFsRequest = new RetrieveProcessInstancesRequest
            {
                EntityId = entity.Id,
                EntityLogicalName = entity.LogicalName
            };

            RetrieveProcessInstancesResponse entityBPFsResponse = (RetrieveProcessInstancesResponse)crmService.Execute(entityBPFsRequest);

            // Declare variables to store values returned in response
            if(entityBPFsResponse.Processes != null && entityBPFsResponse.Processes.Entities != null)
            {
                int processCount = entityBPFsResponse.Processes.Entities.Count;
                activeProcessInstance = entityBPFsResponse.Processes.Entities[0];
            }
            
            return activeProcessInstance;
        }

        public RetrieveActivePathResponse GetAllStagesOfBPF(Guid activeBPFId,Guid activeStageId,ref int activeStagePosition, IOrganizationService crmService)
        {
            // Retrieve the process stages in the active path of the current process instance
            RetrieveActivePathRequest pathReq = new RetrieveActivePathRequest
            {
                ProcessInstanceId = activeBPFId
            };
            RetrieveActivePathResponse pathResp = (RetrieveActivePathResponse)crmService.Execute(pathReq);

            //strBuilder.AppendLine("\nRetrieved stages in the active path of the process instance:");

            string activeStageName = string.Empty;
            //int activeStagePosition = -1;
            for (int i = 0; i < pathResp.ProcessStages.Entities.Count; i++)
            {
                // Retrieve the active stage name and active stage position based on the activeStageId for the process instance
                if (pathResp.ProcessStages.Entities[i].Attributes["processstageid"].ToString() == activeStageId.ToString())
                {
                    activeStageName = pathResp.ProcessStages.Entities[i].Attributes["stagename"].ToString();
                    activeStagePosition = i;
                }
            }
            return pathResp;
        }
    }
}
